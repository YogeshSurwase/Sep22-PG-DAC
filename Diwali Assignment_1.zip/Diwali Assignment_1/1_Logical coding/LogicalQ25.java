import java.util.Scanner;

class LogicalQ25
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		for(int i=1; i<=n;i++)
		{
			for(int j=i;j<=n;j++)
			{
				System.out.print(j);
			}
			for(int k=1;k<i;k++)
			{
				System.out.print(k);
			}
			System.out.println();
		}
	}
}


/*OUTPUT
7
1234567
2345671
3456712
4567123
5671234
6712345
7123456
============
6
123456
234561
345612
456123
561234
612345
===========
5
12345
23451
34512
45123
51234
*/