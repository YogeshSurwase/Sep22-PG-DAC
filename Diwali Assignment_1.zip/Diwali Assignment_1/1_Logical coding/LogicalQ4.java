import java.util.*;
class LogicalQ4
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		for(int i=0;i<n;i++)
		{
			for(int j=i;j<n;j++)
			{
				System.out.print(" ");
			}
			for(int k=0;k<=i;k++)
			{
				if(k>=1&k<i)			// 1 2 1
				{
					if(k>1&k<i-1)			// 1 4 6 4 1
					{
						if(k>2&k<i-2)			// 1 6 8 10 8 6 1
						{
							if(k>3&k<i-3)      		// 1 8 10 12 16 12 10 8 1
							{
								i+=6;
								System.out.print(i+" ");
								i-=6;
							}
							else
							{
								i+=4;
								System.out.print(i+" ");
								i-=4;
							}
						}
						else
						{
							
							i+=2;
							System.out.print(i+" ");
							i-=2;
						}
					}
					
					else
					{
						System.out.print(i+" ");
					}
				}
				else
				{
					System.out.print("1 ");
				}
			}
			System.out.println();
		}
		
	}
}

/*OUTPUT
5
     1
    1 1
   1 2 1
  1 3 3 1
 1 4 6 4 1
=================
6
      1
     1 1
    1 2 1
   1 3 3 1
  1 4 6 4 1
 1 5 7 7 5 1
==================
7
       1
      1 1
     1 2 1
    1 3 3 1
   1 4 6 4 1
  1 5 7 7 5 1
 1 6 8 10 8 6 1
===================

*/