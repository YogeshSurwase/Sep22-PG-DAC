import java.util.Scanner;

class LogicalQ22
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		
		for(int i=1;i<=n;i++)
		{
			for(int j=i;j<n;j++)
			{
				System.out.print("1");
			}
			for(int k=1;k<=i;k++)
			{
				System.out.print(i);
			}
			
			System.out.println();
		}
	}
}

/*

7			//user input
1111111
1111122
1111333
1114444
1155555
1666666
7777777
==========
8			//user input
11111111
11111122
11111333
11114444
11155555
11666666
17777777
88888888

*/