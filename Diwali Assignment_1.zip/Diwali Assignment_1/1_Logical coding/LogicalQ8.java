import java.util.Scanner;

class LogicalQ8
{
	public static void main(String args[])
	{
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		//int a=1;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				if(j%2!=0)
					System.out.print("1");
				else
					System.out.print("0");
				//a++;
			}
			System.out.println();
		}
		
		
	}
}
/*OUTPUT
5		//TAKING user inpput
1
10
101
1010
10101
========
6			//TAKING user inpput
1
10
101
1010
10101
101010
=========
7			//TAKING user inpput
1
10
101
1010
10101
101010
1010101


*/