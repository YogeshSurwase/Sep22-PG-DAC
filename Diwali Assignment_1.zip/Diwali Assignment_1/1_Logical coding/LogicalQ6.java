import java.util.Scanner;

class LogicalQ6
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		
		for(int i=1;i<=n;i++)
		{
			for(int j=i;j>0;j--)
			{
				System.out.print(j);
			}
			System.out.println();
		}
	}
}

/*OUTPUT
5			//user input
1
21
321
4321
54321
=======
6			//user input
1
21
321
4321
54321
654321
========
7			//user input
1
21
321
4321
54321
654321
7654321



*/