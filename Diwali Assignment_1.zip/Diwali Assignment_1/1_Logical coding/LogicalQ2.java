import java.util.Scanner;
class LogicalQ2
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		
		for(int l=0;l<2*n;l++)
		{
			System.out.print("* ");
		}
		System.out.println();
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(" ");
			}
			for(int k=i;k<n;k++)
			{
				if(k>i&k<n-1)
					System.out.print("  ");
				else
					System.out.print("* ");
			}
			System.out.println();
		}
			
	}
}
/*OUTPUT
5
* * * * * * * * * *
 *       *
  *     *
   *   *
    * *
     *
	 
*/