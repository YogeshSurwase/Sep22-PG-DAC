import java.util.Scanner;

class LogicalQ20
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		for(int i=1;i<n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(" ");
			}
			for(int k=i;k<=n;k++)
			{
				System.out.print(k);
			}
			System.out.println();
		
		}
		for(int i=n;i>=1;i--)
		{
			for(int k=i;k>=1;k--)
			{
				System.out.print(" ");
			}
			for(int j=n;j>=i;j--)
			{
				System.out.print(j);
			}
			System.out.println();
		}
	}
	
}


/*OUTUT
7
 1234567
  234567
   34567
    4567
     567
      67
       7
      76
     765
    7654
   76543
  765432
 7654321
==================
5
 12345
  2345
   345
    45
     5
    54
   543
  5432
 54321
*/ 