import java.util.Scanner;

class LogicalQ18
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		System.out.println("-----------");
		
		for(int i=n;i>=1;i--)
		{
			for(int j=n;j>=i;j--)
			{
				System.out.print(j);
			}
			System.out.println();
		}
	
		
	}
}



/*OUTPUT
7
-----------
7
76
765
7654
76543
765432
7654321
==================
*/