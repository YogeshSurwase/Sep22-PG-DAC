class LogicalQ1
{
	public static void main(String args[])
	{
		java.util.Scanner sc = new java.util.Scanner(System.in);
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			for(int j=i;j<n;j++)
			{
				System.out.print(" ");
			}
			for(int k=0;k<=i;k++)
			{
				if(k>=1&k<i)
				{
					System.out.print("  ");
				}
				else
				{
					System.out.print("* ");
			
				}
			}
			System.out.println();
			
		}
		for(int l=0;l<2*n;l++)
			{
				System.out.print("* ");
			}
	}
}