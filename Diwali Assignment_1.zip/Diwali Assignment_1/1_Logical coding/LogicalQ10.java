import java.util.Scanner;

class LogicalQ10
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		char ch = sc.next().charAt(0);
		for(char i='A';i<=ch;i++)
		{
			for(char j='A';j<=i;j++)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}
}

/*OUTPUT

F   //user input
A
A B
A B C
A B C D
A B C D E
A B C D E F
==================
I		//user input
A
A B
A B C
A B C D
A B C D E
A B C D E F
A B C D E F G
A B C D E F G H
A B C D E F G H I

*/