import java.util.Scanner;

class LogicalQ9
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		
		for(int i=1;i<n;i++)
		{
			for(int k=1;k<=i;k++)
			{
				System.out.print(" ");
			}
			for(int j=i;j<=n;j++)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
		
		for(int i=n;i>0;i--)
		{
			for(int k=i;k>0;k--)
			{
				System.out.print(" ");
			}
			for(int j=i;j<=n;j++)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}
}
/*OUTPUT
5			// user input 
 1 2 3 4 5
  2 3 4 5
   3 4 5
    4 5
     5
    4 5
   3 4 5
  2 3 4 5
 1 2 3 4 5
================
6				//user input
 1 2 3 4 5 6
  2 3 4 5 6
   3 4 5 6
    4 5 6
     5 6
      6
     5 6
    4 5 6
   3 4 5 6
  2 3 4 5 6
 1 2 3 4 5 6
*/