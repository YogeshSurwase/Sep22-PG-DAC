import java.util.Scanner;

class LogicalQ7
{
	public static void main(String args[])
	{
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int a=1;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(a%2!=0)
					System.out.print("1");
				else
					System.out.print("0");
				a++;
			}
			System.out.println();
		}
		
		
	}
}
/*OUTPUT
5		//taking user input
10101
01010
10101
01010
10101
===========
7		//taking user input
1010101
0101010
1010101
0101010
1010101
0101010
1010101

*/