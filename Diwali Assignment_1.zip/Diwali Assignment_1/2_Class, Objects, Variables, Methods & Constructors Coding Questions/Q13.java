class Q13
{
	static void display()
	{
		System.out.println("method without parimeter and without return type");
	
	}
	
	public static void main(String args[])
	{
		display();
	}	
	
}
