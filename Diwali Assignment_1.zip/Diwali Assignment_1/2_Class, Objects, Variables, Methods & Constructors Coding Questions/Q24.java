class Q24
{
	static int x;  //static variable
	
	public static void  main(String args[])
	{
		x=12;
		
		System.out.println(x);
	
	
	
	}

}