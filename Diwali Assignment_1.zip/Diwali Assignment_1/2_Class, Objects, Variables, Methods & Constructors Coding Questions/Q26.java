class Q26
{
	public static void  main(String args[])
	{
		byte x=1;
		byte y=2;
		byte z;
		
		z=(byte)(x+y);
		
		System.out.println(z);
	
	
	
	}

}