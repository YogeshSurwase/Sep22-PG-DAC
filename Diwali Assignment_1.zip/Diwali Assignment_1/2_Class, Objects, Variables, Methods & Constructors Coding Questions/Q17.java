class Q17 
{
	static int i;
	
	
	Q17(int x)
	{
		i=x;
	}
	
	public static void main(String args[])
	{
		Q17 s2 = new Q17(5);
		
		
		System.out.println(i);
	}
	
}