class Q16
{
	static final int x = 5;
	
	public static void main(String args[])
	{
		//x=6;     //error if we try to intialise final value variable
		System.out.println(5);
	}
	
}
