class Q10
{
	static void swap(int x, int y)
	{
		int temp = x;
		x= y;
		y= temp;
		
		System.out.println("swap done");
		System.out.println("swap done");
	}
	
	public static void main(String args[])
	{
		swap(5,10);
		
	}	
	
}
