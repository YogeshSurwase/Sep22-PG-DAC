class Q12
{
	static int display()
	{
		return 1;
	
	}
	
	public static void main(String args[])
	{
		int z = display();
		System.out.println(z);
	}
	
}
