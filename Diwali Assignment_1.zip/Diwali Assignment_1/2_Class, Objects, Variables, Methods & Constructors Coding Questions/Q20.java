
class Q20 
{
	static String x;
	static String y;
	
	Q20()
	{
	}
	
	Q20(String x,String y)
	{
		this.x = x;
		this.y = y;
		
	}
	
	
	
	public static void main(String args[])
	{
		Q20 s1 = new Q20("Yogi","Rao");
		
		System.out.println(x);
		System.out.println(y);
	}
	
}