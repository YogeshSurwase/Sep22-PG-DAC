class Q14
{
	static void display(int x, int y)
	{
		System.out.println(x);
		System.out.println(y);
	
	}
	
	public static void main(String args[])
	{
		display(5,5);
	}
	
}
