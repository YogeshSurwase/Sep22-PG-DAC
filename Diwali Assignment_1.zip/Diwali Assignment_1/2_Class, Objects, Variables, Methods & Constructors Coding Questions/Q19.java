
class Q19 
{
	static String x;
	static String y;
	
	Q19()
	{
	}
	
	Q19(String x,String y)
	{
		this.x = x;
		this.y = y;
		
	}
	
	
	
	public static void main(String args[])
	{
		Q19 s1 = new Q19("Yogi","Rao");
		
		System.out.println(x);
		System.out.println(y);
	}
	
}